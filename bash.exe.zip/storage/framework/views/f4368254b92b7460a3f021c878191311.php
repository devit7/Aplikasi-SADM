<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>APLIKASI - SADM</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <script>
        (function(m, a, z, e) {
            var s, t;
            try {
                t = m.sessionStorage.getItem('maze-us');
            } catch (err) {}

            if (!t) {
                t = new Date().getTime();
                try {
                    m.sessionStorage.setItem('maze-us', t);
                } catch (err) {}
            }

            s = a.createElement('script');
            s.src = z + '?apiKey=' + e;
            s.async = true;
            a.getElementsByTagName('head')[0].appendChild(s);
            m.mazeUniversalSnippetApiKey = e;
        })(window, document, 'https://snippet.maze.co/maze-universal-loader.js', 'db08c225-5ce2-4bf7-9f44-8c88c999648d');
    </script>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal9325e77e31762c6f8c2e878f53d3687d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9325e77e31762c6f8c2e878f53d3687d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.walas-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('walas-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9325e77e31762c6f8c2e878f53d3687d)): ?>
<?php $attributes = $__attributesOriginal9325e77e31762c6f8c2e878f53d3687d; ?>
<?php unset($__attributesOriginal9325e77e31762c6f8c2e878f53d3687d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9325e77e31762c6f8c2e878f53d3687d)): ?>
<?php $component = $__componentOriginal9325e77e31762c6f8c2e878f53d3687d; ?>
<?php unset($__componentOriginal9325e77e31762c6f8c2e878f53d3687d); ?>
<?php endif; ?>
    <div class="flex flex-col min-h-screen bg-gray-100 p-6">
        <div class="flex flex-col items-start mb-6">
            <h1 class="text-2xl font-bold">Kelas List</h1>
            <div class=" flex">
                <form method="GET" action="<?php echo e(route('walas.index')); ?>" class="flex space-x-2">
                    <?php echo csrf_field(); ?>
                    <select name="semester" class="p-2 border rounded shadow-sm" onchange="this.form.submit()">
                        <option value="">Pilih Semester</option>
                        <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sem); ?>" <?php echo e(request('semester') == $sem ? 'selected' : ''); ?>>
                                <?php echo e($sem); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
                <form method="GET" action="<?php echo e(route('walas.index')); ?>" class="flex space-x-2">
                    <?php echo csrf_field(); ?>
                    <select name="tahun_ajaran" class="p-2 border rounded shadow-sm" onchange="this.form.submit()">
                        <option value="">Pilih Tahun Ajar</option>
                        <?php $__currentLoopData = $tahun_ajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tahun); ?>"
                                <?php echo e(request('tahun_ajaran') == $tahun ? 'selected' : ''); ?>>
                                <?php echo e($tahun); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </form>
            </div>
        </div>

        <div class="flex flex-wrap">
            <div class="grid grid-cols-2 gap-4">

                <?php $__empty_1 = true; $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if(
                        (request('tahun_ajaran') == '' || $kelas->tahun_ajaran == request('tahun_ajaran')) &&
                            (request('semester') == '' || $kelas->matapelajaran->contains('semester', request('semester')))): ?>
                        <a href=<?php echo e(route('walas.list-siswa', $kelas->id)); ?>>
                            <button class="bg-white w-[200px] h-[250px] rounded-lg shadow-md flex flex-col">
                                <div
                                    class="bg-red-300 h-[150px] p-6 shadow-md text-center flex justify-center items-center w-full">
                                    <h2 class="text-3xl font-bold text-white"><?php echo e($kelas->nama_kelas); ?></h2>
                                </div>
                                <div class="flex flex-col text-start p-3">
                                    <p class="text-black font-semibold mt-2">KELAS
                                        
                                        <?php echo e($kelas->nama_kelas); ?><br>
                                        <?php if($kelas->matapelajaran->count() > 0 && $kelas->matapelajaran->first()): ?>
                                            <?php echo e($kelas->matapelajaran->first()->semester); ?>-<?php echo e($kelas->tahun_ajaran); ?>

                                        <?php else: ?>
                                            <?php echo e($kelas->tahun_ajaran); ?>

                                        <?php endif; ?>
                                    </p>
                                    <p class="text-gray-700 mt-2"><?php echo e($kelas->siswa_count); ?> 👥</p>
                                </div>

                            </button>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Data tidak ada</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/walas/dashboard-walas.blade.php ENDPATH**/ ?>