<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>APLIKASI - SADM</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <script>
        (function(m, a, z, e) {
            var s, t;
            try {
                t = m.sessionStorage.getItem('maze-us');
            } catch (err) {}

            if (!t) {
                t = new Date().getTime();
                try {
                    m.sessionStorage.setItem('maze-us', t);
                } catch (err) {}
            }

            s = a.createElement('script');
            s.src = z + '?apiKey=' + e;
            s.async = true;
            a.getElementsByTagName('head')[0].appendChild(s);
            m.mazeUniversalSnippetApiKey = e;
        })(window, document, 'https://snippet.maze.co/maze-universal-loader.js', 'db08c225-5ce2-4bf7-9f44-8c88c999648d');
    </script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.9/dist/cdn.min.js"></script>
</head>

<body class=" bg-[#f5f6fa]">
    <?php if (isset($component)) { $__componentOriginal9325e77e31762c6f8c2e878f53d3687d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9325e77e31762c6f8c2e878f53d3687d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.walas-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('walas-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9325e77e31762c6f8c2e878f53d3687d)): ?>
<?php $attributes = $__attributesOriginal9325e77e31762c6f8c2e878f53d3687d; ?>
<?php unset($__attributesOriginal9325e77e31762c6f8c2e878f53d3687d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9325e77e31762c6f8c2e878f53d3687d)): ?>
<?php $component = $__componentOriginal9325e77e31762c6f8c2e878f53d3687d; ?>
<?php unset($__componentOriginal9325e77e31762c6f8c2e878f53d3687d); ?>
<?php endif; ?>
    <div class=" flex">
        <!-- Check if we are on a page with a kelas object -->
        <?php if(isset($kelas) && isset($kelas->id)): ?>
            <?php if (isset($component)) { $__componentOriginalc1b36b8d3ccf649374666d2b0d85ea42 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1b36b8d3ccf649374666d2b0d85ea42 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alternative-walas-sidebar','data' => ['kelasId' => $kelas->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alternative-walas-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['kelasId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($kelas->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1b36b8d3ccf649374666d2b0d85ea42)): ?>
<?php $attributes = $__attributesOriginalc1b36b8d3ccf649374666d2b0d85ea42; ?>
<?php unset($__attributesOriginalc1b36b8d3ccf649374666d2b0d85ea42); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1b36b8d3ccf649374666d2b0d85ea42)): ?>
<?php $component = $__componentOriginalc1b36b8d3ccf649374666d2b0d85ea42; ?>
<?php unset($__componentOriginalc1b36b8d3ccf649374666d2b0d85ea42); ?>
<?php endif; ?>
        <?php else: ?>
            <?php if (isset($component)) { $__componentOriginale8a20470385919f486d4923e244c9277 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale8a20470385919f486d4923e244c9277 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.walas-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('walas-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale8a20470385919f486d4923e244c9277)): ?>
<?php $attributes = $__attributesOriginale8a20470385919f486d4923e244c9277; ?>
<?php unset($__attributesOriginale8a20470385919f486d4923e244c9277); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8a20470385919f486d4923e244c9277)): ?>
<?php $component = $__componentOriginale8a20470385919f486d4923e244c9277; ?>
<?php unset($__componentOriginale8a20470385919f486d4923e244c9277); ?>
<?php endif; ?>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="<?php echo e(asset('js/flowbite.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/layouts/main-walas.blade.php ENDPATH**/ ?>