<?php $__env->startSection('content'); ?>
<div class="w-full bg-gray-100 p-6">
    <div class="w-24 mx-1 border-collapse border rounded-md bg-red-600 hover:bg-red-500 p-2 text-center mb-2">
        <a href="<?php echo e(route('walas.manajemen-nilai.index')); ?>" class="text-white flex items-center gap-1 justify-center hover:text-gray-100 font-medium text-base">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="size-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 15 3 9m0 0 6-6M3 9h12a6 6 0 0 1 0 12h-3" />
                </svg>

                Kembali</a>
    </div>
    <h1 class="text-2xl font-bold mb-4">Nilai / <?php echo e($data['mapel']['nama_mapel']); ?></h1>

    <?php if(session()->has('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo e(session('success')); ?></span>
    </div>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo e(session('error')); ?></span>
    </div>
    <?php endif; ?>

    <div class="bg-white p-4 shadow-md rounded-lg">
        <?php if (isset($component)) { $__componentOriginal74631a4b16323f894b9f26b299ddae85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74631a4b16323f894b9f26b299ddae85 = $attributes; } ?>
<?php $component = App\View\Components\Tables::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tables::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <table class="w-full border-collapse border rounded-md text-sm" id="table">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border p-2">No</th>
                        <th class="border p-2">Nama</th>
                        <th class="border p-2">UTS</th>
                        <th class="border p-2">UAS</th>
                        <th class="border p-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data['siswa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td class="border p-2"><?php echo e($index + 1); ?></td>
                        <td class="border p-2"><?php echo e($siswa->nama); ?></td>
                        <td class="border p-2">
                            <?php
                            $nilai = collect($data['mapel']['nilai'])->first(function ($nilai) use ($siswa) {
                            return $nilai->detailKelas->siswa_id === $siswa->id;
                            });
                            ?>
                            <?php echo e($nilai ? $nilai->nilai_uts : '0'); ?>

                        </td>
                        <td class="border p-2">
                            <?php echo e($nilai ? $nilai->nilai_uas : '0'); ?>

                        </td>
                        <td class="border p-2">
                            <div x-data="{ open: false }">
                                <button @click="open = true" class="text-blue-600 hover:text-blue-800">
                                    ✏️
                                </button>

                                <?php if (isset($component)) { $__componentOriginal4fe0218345666ba9d9a2b62c88c1ee8c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4fe0218345666ba9d9a2b62c88c1ee8c = $attributes; } ?>
<?php $component = App\View\Components\ModalNilai::resolve(['title' => 'Input Nilai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-nilai'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ModalNilai::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                    <form action="<?php echo e(route('walas.manajemen-nilai.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id_mapel" value="<?php echo e($data['mapel']['id']); ?>">
                                        <input type="hidden" name="id_kelas" value="<?php echo e($data['mapel']['kelas']->id); ?>">
                                        <div class="mb-4">
                                            <label class="flex justify-start text-sm font-medium mb-1 opacity-50">Nama</label>
                                            <input type="text" name="nama" value="<?php echo e($siswa->nama); ?>" readonly class="w-full border rounded px-3 py-2 bg-gray-100">
                                        </div>
                                        <div class="mb-4">
                                            <label class="flex justify-start text-sm font-medium mb-1 opacity-50">UTS</label>
                                            <input type="number" name="uts" value="<?php echo e($nilai ? $nilai->nilai_uts : ''); ?>" class="w-full border rounded px-3 py-2" placeholder="ex: 80" required>
                                        </div>
                                        <div class="mb-4">
                                            <label class="flex justify-start text-sm font-medium mb-1 opacity-50">UAS</label>
                                            <input type="number" name="uas" value="<?php echo e($nilai ? $nilai->nilai_uas : ''); ?>" class="w-full border rounded px-3 py-2" placeholder="ex: 80" required>
                                        </div>
                                        <div class="flex flex-col justify-center gap-2">
                                            <button type="submit" class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded">
                                                Confirm
                                            </button>
                                            <button type="button" @click="open = false" class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded">
                                                Cancel
                                            </button>
                                        </div>
                                    </form>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4fe0218345666ba9d9a2b62c88c1ee8c)): ?>
<?php $attributes = $__attributesOriginal4fe0218345666ba9d9a2b62c88c1ee8c; ?>
<?php unset($__attributesOriginal4fe0218345666ba9d9a2b62c88c1ee8c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4fe0218345666ba9d9a2b62c88c1ee8c)): ?>
<?php $component = $__componentOriginal4fe0218345666ba9d9a2b62c88c1ee8c; ?>
<?php unset($__componentOriginal4fe0218345666ba9d9a2b62c88c1ee8c); ?>
<?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $attributes = $__attributesOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__attributesOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $component = $__componentOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__componentOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-walas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/walas/manajemen-nilai/show.blade.php ENDPATH**/ ?>