<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SADM - Ortu</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <?php echo $__env->yieldPushContent('styles'); ?>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="m-0 p-0 bg-[#F5F9FD]">
    <?php if (isset($component)) { $__componentOriginald1d29bf6f1f1be32d55dd2ad58997770 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald1d29bf6f1f1be32d55dd2ad58997770 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ortu-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ortu-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald1d29bf6f1f1be32d55dd2ad58997770)): ?>
<?php $attributes = $__attributesOriginald1d29bf6f1f1be32d55dd2ad58997770; ?>
<?php unset($__attributesOriginald1d29bf6f1f1be32d55dd2ad58997770); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald1d29bf6f1f1be32d55dd2ad58997770)): ?>
<?php $component = $__componentOriginald1d29bf6f1f1be32d55dd2ad58997770; ?>
<?php unset($__componentOriginald1d29bf6f1f1be32d55dd2ad58997770); ?>
<?php endif; ?>
    <div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/layouts/main-ortu.blade.php ENDPATH**/ ?>