<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <div class="w-24 mx-1 border-collapse border rounded-md bg-red-600 hover:bg-red-500 p-2 text-center mb-2">
        <a href="<?php echo e(route('walas.manajemen-absen.index')); ?>" class="text-white flex items-center gap-1 justify-center hover:text-gray-100 font-medium text-base">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                    stroke="currentColor" class="size-5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 15 3 9m0 0 6-6M3 9h12a6 6 0 0 1 0 12h-3" />
                </svg>

                Kembali</a>
    </div>
    <h1 class="text-2xl font-bold mb-6 ml-1">Absensi</h1>

    <?php if(session('error')): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo e(session('error')); ?></span>
        <button type="button" class="absolute top-0 right-0 px-4 py-3" data-bs-dismiss="alert" aria-label="Close">
            <span class="sr-only">Close</span>
            <svg class="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                <path d="M6.293 6.293a1 1 0 011.414 0L10 8.586l2.293-2.293a1 1 0 111.414 1.414L11.414 10l2.293 2.293a1 1 0 01-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 01-1.414-1.414L8.586 10 6.293 7.707a1 1 0 010-1.414z" clip-rule="evenodd" fill-rule="evenodd"></path>
            </svg>
        </button>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow-md">
        <div class="p-6">
            <h2 class="text-xl font-semibold text-center mb-2">Daftar Presensi</h2>
            <p class="text-center text-gray-600 mb-6">Tanggal <?php echo e(\Carbon\Carbon::parse($tanggal)->format('d/m/Y')); ?></p>

            <form action="<?php echo e(route('walas.manajemen-absen.simpan')); ?>" method="POST" id="presensiForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="presensi_id" value="<?php echo e($presensi->id); ?>">

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-16">
                                    No
                                </th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Nama
                                </th>
                                <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Keterangan
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $detailPresensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo e($index + 1); ?>.
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo e($detail->siswa->nama); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex space-x-6">
                                        <div class="flex items-center">
                                            <input id="masuk_<?php echo e($detail->siswa_id); ?>"
                                                name="siswa_status[<?php echo e($detail->siswa_id); ?>]"
                                                type="radio"
                                                value="masuk"
                                                <?php echo e($detail->status == 'masuk' ? 'checked' : ''); ?>

                                                class="h-4 w-4 text-green-600 border-gray-300 focus:ring-green-500">
                                            <label for="masuk_<?php echo e($detail->siswa_id); ?>" class="ml-2 block text-sm text-gray-900">
                                                Masuk
                                            </label>
                                        </div>
                                        <div class="flex items-center">
                                            <input id="sakit_<?php echo e($detail->siswa_id); ?>"
                                                name="siswa_status[<?php echo e($detail->siswa_id); ?>]"
                                                type="radio"
                                                value="sakit"
                                                <?php echo e($detail->status == 'sakit' ? 'checked' : ''); ?>

                                                class="h-4 w-4 text-yellow-600 border-gray-300 focus:ring-yellow-500">
                                            <label for="sakit_<?php echo e($detail->siswa_id); ?>" class="ml-2 block text-sm text-gray-900">
                                                Sakit
                                            </label>
                                        </div>
                                        <div class="flex items-center">
                                            <input id="izin_<?php echo e($detail->siswa_id); ?>"
                                                name="siswa_status[<?php echo e($detail->siswa_id); ?>]"
                                                type="radio"
                                                value="izin"
                                                <?php echo e($detail->status == 'izin' ? 'checked' : ''); ?>

                                                class="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500">
                                            <label for="izin_<?php echo e($detail->siswa_id); ?>" class="ml-2 block text-sm text-gray-900">
                                                Izin
                                            </label>
                                        </div>
                                        <div class="flex items-center">
                                            <input id="alpha_<?php echo e($detail->siswa_id); ?>"
                                                name="siswa_status[<?php echo e($detail->siswa_id); ?>]"
                                                type="radio"
                                                value="alpha"
                                                <?php echo e($detail->status == 'alpha' ? 'checked' : ''); ?>

                                                class="h-4 w-4 text-red-600 border-gray-300 focus:ring-red-500">
                                            <label for="alpha_<?php echo e($detail->siswa_id); ?>" class="ml-2 block text-sm text-gray-900">
                                                Alpha
                                            </label>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="flex justify-end mt-6">
                    <button type="button" id="simpanBtn" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2">
                        Simpan Presensi
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Using the confirmation-modal component with Tailwind CSS -->
<?php if (isset($component)) { $__componentOriginal5b8b2d0f151a30be878e1a760ec3900c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.confirmation-modal','data' => ['id' => 'confirmationModal','title' => 'Konfirmasi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('confirmation-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'confirmationModal','title' => 'Konfirmasi']); ?>
    <p class="text-sm text-gray-500">
        Apakah anda yakin menyimpan presensi?
    </p>

     <?php $__env->slot('footer', null, []); ?> 
        <button type="button" id="confirmSimpan" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
            Simpan
        </button>
        <button type="button" id="cancelSimpan" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-red-700 text-base font-medium text-white hover:bg-red-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
            Batal
        </button>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c)): ?>
<?php $attributes = $__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c; ?>
<?php unset($__attributesOriginal5b8b2d0f151a30be878e1a760ec3900c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b8b2d0f151a30be878e1a760ec3900c)): ?>
<?php $component = $__componentOriginal5b8b2d0f151a30be878e1a760ec3900c; ?>
<?php unset($__componentOriginal5b8b2d0f151a30be878e1a760ec3900c); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const simpanBtn = document.getElementById('simpanBtn');
        const confirmSimpan = document.getElementById('confirmSimpan');
        const cancelSimpan = document.getElementById('cancelSimpan');
        const presensiForm = document.getElementById('presensiForm');
        const confirmationModal = document.getElementById('confirmationModal');

        simpanBtn.addEventListener('click', function() {
            // Show confirmation modal
            confirmationModal.classList.remove('hidden');
        });

        confirmSimpan.addEventListener('click', function() {
            // Submit the form
            presensiForm.submit();
        });

        cancelSimpan.addEventListener('click', function() {
            // Hide modal
            confirmationModal.classList.add('hidden');
        });

        // Close modal when clicking outside
        window.addEventListener('click', function(event) {
            if (event.target === confirmationModal) {
                confirmationModal.classList.add('hidden');
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main-walas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/walas/manajemen-absensi/show.blade.php ENDPATH**/ ?>