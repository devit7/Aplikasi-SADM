<?php

test('admin/logout', function () {
    expect(true)->toBeTrue();
});
