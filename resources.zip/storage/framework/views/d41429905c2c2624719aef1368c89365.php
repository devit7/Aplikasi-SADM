<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-100 p-6">
    <h1 class="text-2xl font-bold mb-4">Siswa</h1>
    <div class="bg-white p-4 shadow-md rounded-lg">
        <?php if (isset($component)) { $__componentOriginal74631a4b16323f894b9f26b299ddae85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74631a4b16323f894b9f26b299ddae85 = $attributes; } ?>
<?php $component = App\View\Components\Tables::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tables::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <table class="w-full border-collapse border rounded-md text-sm " id="table" >
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border p-2">NISN</th>
                        <th class="border p-2">NIS</th>
                        <th class="border p-2">Nama</th>
                        <th class="border p-2">Nama Wali</th>
                        <th class="border p-2">Nomer Wali</th>
                        <th class="border p-2">Jenis Kelamin</th>
                        <th class="border p-2">Tempat Lahir</th>
                        <th class="border p-2">Tgl Lahir</th>
                        <th class="border p-2">Alamat</th>
                        <th class="border p-2">TA</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kelas->siswa->unique('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td class="border p-2"><?php echo e($siswa->nisn); ?></td>
                            <td class="border p-2"><?php echo e($siswa->nis); ?></td>
                            <td class="border p-2"><?php echo e($siswa->nama); ?></td>
                            <td class="border p-2"><?php echo e($siswa->nama_bapak); ?></td>
                            <td class="border p-2"><?php echo e($siswa->no_hp_bapak); ?></td>
                            <td class="border p-2"><?php echo e($siswa->jenis_kelamin); ?></td>
                            <td class="border p-2"><?php echo e($siswa->tempat_lahir); ?></td>
                            <td class="border p-2"><?php echo e($siswa->tanggal_lahir); ?></td>
                            <td class="border p-2"><?php echo e($siswa->alamat); ?></td>
                            <td class="border p-2"><?php echo e($kelas->tahun_ajaran); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $attributes = $__attributesOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__attributesOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $component = $__componentOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__componentOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main-walas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/walas/list-siswa.blade.php ENDPATH**/ ?>