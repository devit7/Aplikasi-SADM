<?php $__env->startSection('content'); ?>
<div class="w-full bg-gray-100 p-6">
    <div class="w-24 mx-1 border-collapse border rounded-md bg-red-600 hover:bg-red-500 p-2 text-center mb-2">
        <a href="<?php echo e(route('walas.index')); ?>" class="text-white hover:text-gray-100 font-medium text-base">
            < Kembali</a>
    </div>
    <h1 class="text-2xl font-bold mb-4">Nilai</h1>
    <div class="bg-white p-4 shadow-md rounded-lg">
        <?php if (isset($component)) { $__componentOriginal74631a4b16323f894b9f26b299ddae85 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74631a4b16323f894b9f26b299ddae85 = $attributes; } ?>
<?php $component = App\View\Components\Tables::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tables'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Tables::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <table class="w-full border-collapse border rounded-md text-sm" id="table">
                <thead>
                    <tr class="bg-gray-200">
                        <th class="border p-2">No</th>
                        <th class="border p-2">Mata Pelajaran</th>
                        <th class="border p-2">Semester</th>
                        <th class="border p-2">Status Nilai</th>
                        <th class="border p-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $mapel_with_nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td class="border p-2"><?php echo e($index + 1); ?></td>
                        <td class="border p-2"><?php echo e($mapel->nama_mapel); ?></td>
                        <td class="border p-2"><?php echo e($mapel->semester); ?></td>
                        <td class="border p-2"><?php echo e($mapel->status_nilai); ?></td>
                        <td class="border p-2">
                            <a href="<?php echo e(route('walas.manajemen-nilai.show', $mapel->id)); ?>">✏️</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $attributes = $__attributesOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__attributesOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74631a4b16323f894b9f26b299ddae85)): ?>
<?php $component = $__componentOriginal74631a4b16323f894b9f26b299ddae85; ?>
<?php unset($__componentOriginal74631a4b16323f894b9f26b299ddae85); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main-walas', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/walas/manajemen-nilai/index.blade.php ENDPATH**/ ?>