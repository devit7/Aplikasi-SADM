<?php $__env->startSection('nilai-kehadiran-content'); ?>
    
    
<div id="pdf-container" class="flex flex-col items-center justify-center"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.min.js"></script>
    <script>
document.addEventListener("DOMContentLoaded", function() {
    const url = "<?php echo e(route('ortu.showRaport')); ?>";

    // Set the workerSrc (important: match the version)
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.13.216/pdf.worker.min.js';

    const container = document.getElementById('pdf-container');

    // Load PDF
    const loadingTask = pdfjsLib.getDocument(url);
    loadingTask.promise.then(function(pdf) {
        console.log('PDF loaded');

        // Loop all pages
        for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
            pdf.getPage(pageNumber).then(function(page) {
                console.log('Page loaded', pageNumber);

                const viewport = page.getViewport({ scale: 1.5 });

                // Create canvas and render
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;

                // Center canvas using Tailwind
                canvas.classList.add('mx-auto', 'my-4', 'shadow-md', 'rounded-lg');

                container.appendChild(canvas);

                const renderContext = {
                    canvasContext: context,
                    viewport: viewport
                };
                page.render(renderContext);
            });
        }
    }, function(reason) {
        console.error('Error loading PDF: ', reason);
    });
});
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.2/moment.min.js"></script>
    <script src="https://cdn.datatables.net/datetime/1.5.1/js/dataTables.dateTime.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#table').DataTable(); // Initialize the DataTable
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.nilai-kehadiran-ortu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/ortu/nilai-ortu.blade.php ENDPATH**/ ?>