<?php $__env->startSection('content'); ?>
    <div class="w-full">
        <div class="flex w-full border border-blue-500 h-9">
            <a href="/ortu/nilai-kehadiran" id="nilai" class="<?php echo e(request()->is('ortu/nilai-kehadiran') ? 'bg-blue-500 text-white' : 'text-blue-500 bg-white'); ?> flex-1 text-center py-1 cursor-pointer">Nilai</a>
            <a href="/ortu/nilai-kehadiran/kehadiran" id="kehadiran" class="<?php echo e(request()->is('ortu/nilai-kehadiran/kehadiran') ? 'bg-blue-500 text-white' : 'text-blue-500 bg-white'); ?> flex-1 text-center py-1 cursor-pointer">Kehadiran</a>
        </div>
    </div>
    <div class="m-5">
        <h1 class="text-3xl font-poppins"> <?php echo e(strtoupper($detailKelas->kelas->nama_kelas . ' tahun ajaran ' . $tahunAjaran)); ?> </h1>
        <h2 class="text-2xl font-poppins"> <?php echo e(strtoupper($siswa->nama)); ?> </h2>
    </div>
    <div>
        <?php echo $__env->yieldContent('nilai-kehadiran-content'); ?>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/datetime/1.5.1/css/dataTables.dateTime.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.main-ortu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project\Kuliah\Laravel\Proyek Tingkat III\project_tingkat_3\resources\views/layouts/nilai-kehadiran-ortu.blade.php ENDPATH**/ ?>