<?php

test('admin/login', function () {
    expect(true)->toBeTrue();
});
